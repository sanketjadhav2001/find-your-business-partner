<footer class="footer pt-3  ">
<div class="container-fluid">
<div class="row align-items-center justify-content-lg-between">
    <div class="col-lg-12">
  <ul class="nav nav-footer   text-lg-start">
    <li class="nav-item">
      <a href="aboutus.html" class="nav-link text-muted" target="_blank">About Us</a>
    </li>
    <li class="nav-item">
      <a href="contactus.html" class="nav-link text-muted" target="_blank">Contact Us</a>
    </li>
    <li class="nav-item">
      <a href="terms.html" class="nav-link pe-0 text-muted" target="_blank">Terms Of Service</a>
    </li>
    <li class="nav-item">
      <a href="privacy.html" class="nav-link pe-0 text-muted" target="_blank">Privacy Policy</a>
    </li>
    <li class="nav-item">
      <a href="guidelines.html" class="nav-link pe-0 text-muted" target="_blank">Community Guidelines</a>
    </li>
  </ul>
</div>
</div>
</div>
        </div>
      </footer>