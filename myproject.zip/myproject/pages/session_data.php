<?php 
session_start();
echo $_SESSION['key_1'];
echo $_SESSION['session_id'];
echo $_SESSION['first_name'];
echo $_SESSION['last_name'];
?>