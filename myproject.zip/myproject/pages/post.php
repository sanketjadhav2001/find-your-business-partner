<div class="fixed-plugin">
    <a class="fixed-plugin-button text-dark position-fixed px-3 py-2" href="chat.php" style="right:7%">
      <i class="fa fa-comments py-2"> </i>
    </a>
    <a class="fixed-plugin-button text-dark position-fixed px-3 py-2" href="postnow.php" >
      <i class="fa fa-pen py-2"> </i>
    </a>
</div>