<?php 
session_start();
if (!isset($_SESSION['session_id'])) {
    // If session ID is not set, user is not logged in. Redirect to index.php
    header("Location: index.php");
    exit();
}

if($_SESSION['user_type'] != 3){
    header("Location: index.php");
}

require('database.php');
$user_id = 0;
if(!isset($_GET['userid']))
{
  $self = 1;
  $user_id = $_SESSION['key_1'];
}
else
{
  $self = 0;
  $user_id = $_GET['userid'];
}
//company
$query = "SELECT * from user WHERE key_1 = $user_id";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$company = ucfirst($row['company']);
$username = ucfirst($row['first_name']);
$lastname = ucfirst($row['last_name']);
$profile_link = $row['profile_link'];
$user_type = $row['user_type'];

require('database.php');
//followers
// Count number of followers
$query = "SELECT COUNT(*) as follower_count FROM nodes WHERE too = $user_id ";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$followers = $row['follower_count'];


//following
// Count number of followers
$query = "SELECT COUNT(*) as follower_count FROM nodes WHERE fromm = $user_id ";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$following = $row['follower_count'];

//company
$query = "SELECT * from user WHERE key_1 = $user_id";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$company = ucfirst($row['company']);
$username = ucfirst($row['first_name']);
$profile_link = $row['profile_link'];
$user_type = $row['user_type'];

//is the user following 
$fromm = $_SESSION['key_1'];
$query = "SELECT COUNT(*) as is_follower FROM nodes WHERE fromm = $fromm AND too = $user_id";
$result = $conn->query($query);
$row = $result->fetch_assoc();
if($row['is_follower'] != 0)
{
  $isfollower = 1;
}
else
{
  $isfollower = 0;
}

//follows you 
$fromm = $_SESSION['key_1'];
$query = "SELECT COUNT(*) as followsyou FROM nodes WHERE fromm = $user_id AND too = $fromm";
$result = $conn->query($query);
$row = $result->fetch_assoc();
if($row['followsyou'] != 0)
{
  $followsyou = 1;
}
else
{
  $followsyou = 0;
}



$row = "";

if(isset($_GET['investors'])){

    $query = "SELECT * FROM user WHERE user_type = '1'";
    $row = mysqli_query($conn, $query);

}else if(isset($_GET['businesses'])){
    
    $query = "SELECT * FROM user WHERE user_type = '0'";
    $row = mysqli_query($conn, $query);

}else if(isset($_GET['reported'])){

    $query = "SELECT * FROM admin_reported";
    $row = mysqli_query($conn, $query);

}else{ header("Location: index.php"); }



?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    Profile Page
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link id="pagestyle" href="../assets/css/myproject.css?v=2.0.4" rel="stylesheet" />
</head>
<body class="g-sidenav-show bg-gray-100" style="background-color: coral;">


<input type="hidden" id="is_follower" value="<?php echo $isfollower; ?>" >
<input type="hidden" id="user_id" value="<?php echo $_SESSION['key_1']; ?>" >
<input type="hidden" id="profileId" value= "<?php echo $_GET['userid']; ?>" >
<input type="hidden" id="user_id_as_per_php" value="<?php echo $user_id; ?>" >
<input type="hidden" id="postidcounter" value= "0" >

<div class="main-content position-relative max-height-vh-100 h-100">
  <div class="card shadow-lg mx-4" style="margin-top:2%;">
    <div class="card-body p-3">
      <div class="row gx-4">
        <div class="col-auto">
          <div class="avatar avatar-xl position-relative">
          <a href="home.php">
          <img src="../assets/img/<?php echo $profile_link; ?>" alt="profile_image" class="w-100 border-radius-lg shadow-sm">
          </a>
         </div>
        </div>
        <div class="col-auto my-auto">
          <div class="h-100">
            <h5 class="mb-1">
              <?php echo $username; ?>
            </h5>
            <p class="mb-0 font-weight-bold text-sm">
            <?php echo $company; if($user_type == 1){echo " (investor)";}?>
            <p class="text-sm" ><?php if($followsyou == 1){echo "follows you";} ?></p>
            </p>
          </div>
        </div>
        <div class="col-auto my-auto">
        </div>
        <div class="col-lg-4 col-md-6 my-sm-auto ms-sm-auto me-sm-0 mx-auto mt-3">
          <div class="nav-wrapper position-relative end-0">
            <ul class="nav nav-pills nav-fill p-1" role="tablist">
            <li class="nav-item">
                <a class=" mb-0 px-0 py-1 active d-flex align-items-center justify-content-center " data-bs-toggle="" href="feed.php<?php if(isset($_GET['userid'])){echo '?userid='.$_GET['userid'].'';} ?>" role="tab" aria-selected="true">
                  <span class="ms-2">MyFeed</span>
                </a>
              </li>
              <li class="nav-item">
                <a class=" mb-0 px-0 py-1 active d-flex align-items-center justify-content-center " data-bs-toggle="" href="following.php<?php if(isset($_GET['userid'])){echo '?userid='.$_GET['userid'].'';} ?>" role="tab" aria-selected="true">
                  <span class="ms-2"><?php echo $following; ?> Following</span>
                </a>
              </li>
              <li class="nav-item">
                <a class=" mb-0 px-0 py-1 d-flex align-items-center justify-content-center " data-bs-toggle="" href="followers.php<?php if(isset($_GET['userid'])){echo '?userid='.$_GET['userid'].'';} ?>" role="tab" aria-selected="false">
                  <span class="ms-2"><?php echo $followers; ?> Followers</span>
                </a>
              </li>
              <?php if($self == 0 && $_GET['userid'] != $_SESSION['key_1'])
              { if($isfollower == 1){
              echo 
              '
              <li class="nav-item">
                <a id="follow-button" class="mb-0 px-0 py-1 d-flex align-items-center justify-content-center " data-bs-toggle="tab" href="javascript:;" role="tab" aria-selected="false">
                  <span class="ms-2">Unfollow</span>
                </a>
              </li> ';
              }
              else
              {
              echo
              '
              <li class="nav-item">
              <a id="follow-button" class=" mb-0 px-0 py-1 d-flex align-items-center justify-content-center " data-bs-toggle="tab" href="javascript:;" role="tab" aria-selected="false">
                <span class="ms-2">Follow</span>
              </a>
              </li> ';
              }
              }
              ?>
              <li class="nav-item">
                <a class=" mb-0 px-0 py-1 active d-flex align-items-center justify-content-center " data-bs-toggle="" href="logout.php" role="tab" aria-selected="true">
                  <span class="ms-2">Logout</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>

<!-- Modal -->
<div class="modal fade " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Comments</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      
      <div class="modal-footer">
      <div class="col-md-9" style="padding:1%;">
        <div class="form-group">
        <input id="comment_data" class="form-control" type="text" value="" placeholder="Add a comment.." required> 
        <input type="hidden" id="comment_post_id" class="form-control" type="text" value="">
       </div>
      </div> 
        <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="" onclick="add_comment(<?php echo $_SESSION['key_1']; ?>)" >Send</button>
      </div>
    </div>
  </div>
</div>

  <div class="container-fluid py-4" id="post">
  </div>
 
 
  <div class="container-fluid py-4" id="post">
      <div class="row">
        <!--go left --> 
    <div class="col-md-3" style="text-align:right;">
    </div>

       <!--post section starts here -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header pb-0">
            </div>
            <div class="card-body">
            <div class="col-md-12" style="text-align:center;">
            <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
    <?php 

            if (mysqli_num_rows($row) > 0) {$index = 0;
                  while ($row1 = mysqli_fetch_assoc($row)) {
                    if(isset($_GET['reported'])){
                        $q = "SELECT first_name, last_name, key_1 , email, admin_ban FROM user WHERE key_1 = ".$row1['admin_reported_by'];
                        $result = $conn->query($q);
                        $rowfrom = $result->fetch_assoc();

                        $q = "SELECT first_name, last_name, key_1 , email, admin_ban FROM user WHERE key_1 = ".$row1['admin_reported_to'];
                        $result = $conn->query($q);
                        $rowto = $result->fetch_assoc();
                    }
                    $index++;
                    echo '
  <tbody>
    <tr>
       ';  if(isset($_GET['reported'])){ echo '
      <th scope="row">'.$index.'</th>
      <td>'.ucfirst($rowto['first_name']).' '.ucfirst($rowto['last_name']).'</td>
      <td>'.$rowto['email'].'</td>
      <td><a href="home.php?userid='.$rowto['key_1'].'" target="_blank">View Profile</a></td>
      <td><a onclick="ban('.$rowto['key_1'].')" href="#" id="bankey_'.$rowto['key_1'].'" >'; if($rowto['admin_ban'] == 1){echo 'UNBAN'; } else{echo 'BAN';} echo '</a></td>   
      </tr>';
       }else
       { echo '
      <td>'.ucfirst($row1['first_name']).' '.ucfirst($row1['last_name']).'</td>
      <td>'.$row1['email'].'</td>
      <td><a href="home.php?userid='.$row1['key_1'].'" target="_blank">View Profile</a></td>
      ';
       }
    }} ?>
   </tbody>
</table>
          </div>
        </div>
      </div>
      </div>
      <!--post section ends here -->
       <!--go right --> 
    <div class="col-md-3">
    </div>

            
    <?php require('post.php'); ?>
    
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <!-- Core -->
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>

    <!-- Theme JS -->
    <script src="../assets/js/myproject.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        //ban user
        function ban(userid){
            userid = userid;
            $.ajax({
                type: 'POST',
                url: 'server.php',
                data: { userid: userid, admin_ban:1},
                success: function(data) {
                    // Handle successful response from nodes.php
                    console.log('ban succesfully');
                    $('#bankey_'+userid).text(data);
                    
                },
                error: function() {
                    // Handle error response from nodes.php
                    console.log('Something went wrong');
                }
                });
        }
    </script>

   





